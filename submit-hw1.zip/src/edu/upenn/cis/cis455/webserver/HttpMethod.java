package edu.upenn.cis.cis455.webserver;

public enum HttpMethod {
    GET,
    HEAD,
    POST
}
