package edu.upenn.cis.cis455.webserver;

public class SendHttpResponseException extends Exception {}
