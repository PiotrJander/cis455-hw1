"""
Performs basic validation after successful compilation
"""
import subprocess, os, requests, time, socket
from requests.exceptions import ConnectionError

s = socket.socket()
s.bind(('', 0))
free_port = str(s.getsockname()[1])
s.close()

build_output = subprocess.check_output(['ant', '-q', 'run'])
if 'BUILD SUCCESSFUL' not in build_output:
	print 'The program failed to build.'
	exit(-1)
	
os.system('java -classpath "target/WEB-INF/lib/*" edu.upenn.cis.cis455.webserver.HttpServer ' + free_port + ' .'+ ' conf/web.xml'+' &')
time.sleep(2)

try:
	requests.get("http://localhost:" + free_port + "/control")
	print 'Connected to /control!'
except ConnectionError:
	print 'Could not connect to /control'
	exit(-1)
try:
	requests.get("http://localhost:" + free_port + "/shutdown")
	print 'Connected to /shutdown!'
except ConnectionError:
	print 'Could not connect to /shutdown'
	exit(-1)

os.system("pkill -f edu.upenn.cis.cis455.webserver.HttpServer")

print 'The program passed validation!'
exit(0)
